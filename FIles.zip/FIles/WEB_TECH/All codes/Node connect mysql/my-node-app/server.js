const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors());  // Enable CORS to allow requests from AngularJS

// Create MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'mydb'
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

// Define an API endpoint to fetch employee data
app.get('/api/employees', (req, res) => {
  const query = 'SELECT * FROM employees';
  db.query(query, (err, result) => {
    if (err) {
      res.status(500).send('Error fetching data');
    } else {
      res.json(result);
    }
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
