const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser'); // Add body-parser for handling POST requests

const app = express();
app.use(cors());
app.use(bodyParser.json());  // Enable JSON parsing for request bodies

// MySQL database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'ticket_booking'
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

// API to fetch tickets with filters
app.get('/api/tickets', (req, res) => {
  let sql = 'SELECT * FROM tickets WHERE availability = true';

  // Apply price filter
  if (req.query.minPrice && req.query.maxPrice) {
    sql += ` AND price BETWEEN ${req.query.minPrice} AND ${req.query.maxPrice}`;
  }

  // Apply sorting (order by)
  if (req.query.orderBy) {
    sql += ` ORDER BY ${req.query.orderBy}`;
  }

  db.query(sql, (err, result) => {
    if (err) {
      res.status(500).send('Error fetching tickets');
    } else {
      res.json(result);
    }
  });
});

// API to book a ticket
app.post('/api/book', (req, res) => {
  const { user_name, user_email, ticket_id } = req.body;

  // Check if the ticket is still available
  const checkAvailability = `SELECT availability FROM tickets WHERE id = ? AND availability = true`;
  db.query(checkAvailability, [ticket_id], (err, result) => {
    if (err || result.length === 0) {
      return res.status(400).json({ error: 'Ticket not available or does not exist' });
    }

    // Insert booking details into the bookings table
    const bookTicket = `INSERT INTO bookings (user_name, user_email, ticket_id, booking_date)
                        VALUES (?, ?, ?, NOW())`;
    db.query(bookTicket, [user_name, user_email, ticket_id], (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Error booking the ticket' });
      }

      // Mark the ticket as unavailable
      const markUnavailable = `UPDATE tickets SET availability = false WHERE id = ?`;
      db.query(markUnavailable, [ticket_id], (err, result) => {
        if (err) {
          return res.status(500).json({ error: 'Error updating ticket availability' });
        }

        res.json({ message: 'Ticket booked successfully' });
      });
    });
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});
