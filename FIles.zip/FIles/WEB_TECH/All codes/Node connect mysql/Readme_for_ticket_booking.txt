1) Takku takkunu pannanum Okay????

2) takku bukku nu pannanum  Teekay???

3) Pulip mittai venum na correct ah porumaya pannanum....

4) Vanga namma program kullla pogalam.......Neenga andha readme file paathingala

5) Database file is present inside the folder... copy the code and execute the query in mysql xampp phpMyAdmin...

6) Above steps panna therilana ennala onnume panna mudiyadhu... unga choli mudinch...

7)  open cmd and navigate to ticket-booking folder OR CREATE ONE.
 	cmd: cd ticket-booking
	cmd: npm init -y
	cmd: npm install express mysql cors

8) server.js code already present inside.... copy the index.html file and pasteit inside xammpp folder in c drive.

9) in the cmd, run the server.js by this command...
	cmd: node server.js

10) open xampp, start apache and open browser type localhost/(your_folder_name)


IMPORTANT NOTE:
MAKE SURE THE MYSQL HAS USERNAME "root" AND PASSWORD "". IF NOT CREATE ONE...SETUP PROPERLY.



 