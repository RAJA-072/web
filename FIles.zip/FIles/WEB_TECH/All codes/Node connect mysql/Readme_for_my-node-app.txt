1) Create database and create a table
CREATE DATABASE mydb;
USE mydb;
CREATE TABLE employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  position VARCHAR(100)
);

INSERT INTO employees (name, position) VALUES
('John Doe', 'Software Engineer'),
('Jane Smith', 'Project Manager'),
('Alice Johnson', 'QA Engineer');



2) Install node js and necessary packages

mkdir my-node-app
cd my-node-app
npm init -y

3) Install npm express for mysql
      cmd: npm install express mysql cors
 
4) write the code in server.js
5) After writing code in server.js and run the code using the following command
	cmd: node server.js 

6) Your server should now be running on http://localhost:3000, and you can access the employee data at http://localhost:3000/api/employees

7) create an index.html file (File is inside the folder... don't worry... all the code already written for you darling)

8) Now run the xampp server and go to the browser and type localhost...

9) That's it.... You scored full marks... give me 10 rupees :)